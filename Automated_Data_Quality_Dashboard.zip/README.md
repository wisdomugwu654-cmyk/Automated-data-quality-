
# Automated Data Quality Dashboard

## Overview

A Python-based data quality automation system that detects,
classifies, cleans, and audits common data-quality problems
in customer datasets.

The project demonstrates automated data validation,
high-confidence cleaning, error reporting, confidence scoring,
and audit logging.

---

## Business Problem

Raw operational data frequently contains:

- Duplicate records
- Missing values
- Invalid email addresses
- Inconsistent formatting
- Invalid transaction amounts

Manually identifying these problems is slow, repetitive,
and difficult to audit.

This project automates the process.

---

## Solution

The system:

1. Loads a raw CSV dataset.
2. Detects data-quality issues.
3. Assigns confidence scores to detected issues.
4. Automatically applies safe, high-confidence corrections.
5. Removes exact duplicate records.
6. Generates a detailed error report.
7. Creates an audit trail of automated changes.
8. Produces a cleaned CSV dataset.
9. Calculates final data-quality metrics.

---

## Architecture

Raw CSV
   |
   v
Data Quality Detection
   |
   +--> Duplicate Detection
   |
   +--> Missing Value Detection
   |
   +--> Email Validation
   |
   +--> Format Consistency Checks
   |
   +--> Transaction Validation
   |
   v
Confidence Scoring
   |
   +--> High Confidence --> Automated Action
   |
   +--> Lower Confidence --> Human Review
   |
   v
Cleaned Dataset + Error Report + Audit Log

---

## Technologies

- Python
- Pandas
- Regular Expressions
- Faker
- Matplotlib
- Google Colab

---

## Results

Records processed: 547

Clean records retained: 500

Duplicates removed: 47

Audit events recorded: 115

Final data-quality score: 95.8%

Average detection confidence: 99.4%

Processing time: 0.0170 seconds

---

## Output Files

### cleaned_customer_data.csv

The cleaned dataset produced by the automation engine.

### error_report.csv

Contains detected quality issues, affected fields,
confidence scores, and issue classifications.

### audit_log.csv

Records automated changes and removals, including:

- Original value
- New value
- Action
- Reason
- Confidence score

### data_quality_summary.txt

Executive summary containing the final project metrics.

---

## Key Design Principle

The system does not blindly modify uncertain data.

High-confidence transformations can be automated,
while ambiguous issues are flagged for human review.

This reduces the risk of introducing incorrect information
while still eliminating repetitive manual data-cleaning work.

---

## Example Business Result

Instead of manually reviewing hundreds of records,
an operations or data team can receive:

"Processed 547 records, removed
47 exact duplicates,
recorded 115 audit events,
and achieved a final data-quality score of
95.8%."

---

## Portfolio Skills Demonstrated

- Data cleaning
- Data validation
- Data quality management
- Python automation
- Pandas
- Error detection
- Confidence scoring
- Audit logging
- Operational reporting
- Data analysis
- Process automation
